package org.stock;

import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.awt.geom.Line2D;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


@RestController
public class pickFinanceUP {

    public List stockList = new LinkedList();
    public String  h ="";




    public pickFinanceUP(){


        InputStream in =  this.getClass().getResourceAsStream("/all_stock.txt");
        BufferedReader br =  new BufferedReader( new java.io.InputStreamReader( in));
        while(true){
            try {
                if (br.ready()){
                    stockList.add(br.readLine());
                }else{
                    break;
                }
        } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }



    }


    @GetMapping("test")
    public void  getUpList(){

        
        
        
    }

    @GetMapping("analysisData")
    public void  analysisData(){
        this.getRemoteData();
    }


    public void  getRemoteData(){



        try {

            HttpHost proxy = new HttpHost("127.0.0.1",8888);
            HttpClient client = new DefaultHttpClient();//定义client对象

            client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);

            HttpPost method = new HttpPost("http://webapi.cninfo.com.cn/api/sysapi/p_sysapi1138?scode=000001");//访问下谷歌的首页

//            method.setHeaders(Arrays.);

            Header [] hs = new Header[this.getHeader().size()];
            this.getHeader().toArray(hs);
            method.setHeaders(hs);
            HttpResponse res = client.execute(method);
            int statusCode =res.getStatusLine().getStatusCode();//状态，一般200为OK状态，其他情况会抛出如404,500,403等错误
            if (statusCode != HttpStatus.SC_OK) {
                System.out.println("远程访问失败。");
            }

            System.out.println (EntityUtils.toString(res.getEntity(),"utf-8"));//输出反馈结果
            EntityUtils.consume(res.getEntity());

        }catch(Exception e ) {
            System.err.println(e);

        }
    }

    public  List<Header>  getHeader(){
        h ="Accept: application/json, text/javascript, */*; q=0.01\n" +
                "Accept-Encoding: gzip, deflate\n" +
                "Accept-Language: zh-CN,zh;q=0.9\n" +
                "Connection: keep-alive\n" +
                "Cookie: Hm_lvt_489bd07e99fbfc5f12cbb4145adb0a9b=1669773711; Hm_lpvt_489bd07e99fbfc5f12cbb4145adb0a9b=1669779808; JSESSIONID=2F77AC89618FC4FC6C11283F61753714\n" +
                "Host: webapi.cninfo.com.cn\n" +
                "mcode: MTY2OTc3OTg1MQ==\n" +
                "Origin: http://webapi.cninfo.com.cn\n" +
                "Referer: http://webapi.cninfo.com.cn/\n" +
                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36\n" +
                "X-Requested-With: XMLHttpRequest" ;

        h  ="Host: webapi.cninfo.com.cn\n" +
                "Connection: keep-alive\n" +
                "Accept: */*\n" +
                "X-Requested-With: XMLHttpRequest\n" +
                "mcode: MTY3MDU4Mjc2Mg==123\n" +
                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36\n" +
                "Origin: http://webapi.cninfo.com.cn\n" +
                "Referer: http://webapi.cninfo.com.cn/\n" +
                "Accept-Encoding: gzip, deflate\n" +
                "Accept-Language: zh-CN,zh;q=0.9\n" +
                "Cookie: Hm_lvt_489bd07e99fbfc5f12cbb4145adb0a9b=1669876518,1670494795,1670495028,1670550145; JSESSIONID=C66FEAD8F38076A3F97C01A9C9FF1176; Hm_lpvt_489bd07e99fbfc5f12cbb4145adb0a9b=1670582018\n";

        List <Header> list = new ArrayList<Header>();

        String [] headers = h.split("\n") ;

        int i=0;
        while (i< headers.length){
            String str =  headers[i++];
            String [] arr =  str.split(":");
            if(arr.length>2){
                arr[0] = str.substring(0 , str.indexOf(":"));
                arr[1] = str.substring(str.indexOf(":")+1 , str.length());
            }
            Header header  = new BasicHeader(arr[0], arr[1]);
            list.add(header);
        }

        return list;


    }



    public static void main(String[] args) {
//        new pickFinanceUP().getRemoteData();

    }











    d
    public void calcMHXY(){



//        召唤兽气血=等级*体力资质/1000+体质点数*成长*6；
//
//        召唤兽魔法=等级*法力资质/500+法力点数*成长*3；
//
//        召唤兽伤害=等级*攻击资质*(14+10*成长)/7500+力量点数*成长；
//
//        召唤兽防御=等级*防御资质*(9.4+19/3*成长)/7500+耐力点数*成长*4/3；
//
//        召唤兽速度=敏捷点数*速度资质/1000
//
//        召唤兽灵力=等级*(法力资质+1662)*(1+成长)/7500+体质点数*0.3+耐力点数*0.2+力量点数*0.4+法力点数*0.7。

        double i = 119 * (2609 + 1640) * (1.252 + 1) / 7500 + 133 * 0.3 + 810 * 0.7 + 137 * .4 + 151 * 0.2 ;

        i = 119 * (2639 + 1640) * (1.264 + 1) / 7500 + 203 * 0.3 + 776 * 0.7 + 145 * .4 + 129 * 0.2 ;

        i = 119 * (3000 + 1640) * (1.224 + 1) / 7500 + 150 * 0.3 +  879 * 0.7 + 134 * .4 + 134 * 0.2 ;

        i = 119 * 3133 /1000 + 203 * 1.3 * 6 ;

        System.out.println("i = " + i);
    }


}
